
angular.module('starter', ['ionic','mainCtrlModule','findCtrlModule','newsCtrlModule','mineCtrlModule','xiangqingCtrlModule'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {

    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {

      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {


  $stateProvider
    .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })

  .state('tab.main', {
    url: '/main',
    views: {
      'tab-main': {
        templateUrl: 'templates/main.html',
        controller: 'mainCtrl'
      }
    }
  })

  .state('tab.find', {
      url: '/find',
      views: {
        'tab-find': {
          templateUrl: 'templates/find.html',
          controller: 'findCtrl'
        }
      }
    })


  .state('tab.news', {
    url: '/news',
    views: {
      'tab-news': {
        templateUrl: 'templates/news.html',
        controller: 'newsCtrl'
      }
    }
  })
  .state('tab.mine', {
    url: '/mine',
    views: {
      'tab-mine': {
        templateUrl: 'templates/mine.html',
        controller: 'mineCtrl'
      }
    }
  })
    .state('tab.xiangqing', {
      url: '/xiangqing',
      params:{abc:''},
      views: {
        'tab-main': {
          templateUrl: 'templates/xiangqing.html',
          controller: 'xiangqingCtrl'
        }
      }
    });

  // $urlRouterProvider.otherwise('/tab/main');
  // console.log('sdfghj');
});
