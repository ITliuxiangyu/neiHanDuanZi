/**
 * Created by qingyun on 2017/6/16.
 */
angular.module('xiangqingCtrlModule',[])
  .controller('xiangqingCtrl',function ($scope,$stateParams,$sce) {
    console.log($stateParams);


    $scope.a = $stateParams.abc.group.share_url;
    $scope.d = $sce.trustAsResourceUrl($scope.a);
  })
