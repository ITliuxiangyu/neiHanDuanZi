/**
 * Created by qingyun on 2017/6/12.
 */
var myUrl = "http://iu.snssdk.com/neihan/stream/mix/v1/?mpic=1&webp=1&essence=1&content_type=-101&message_cursor=-1&am_longitude=113.718788&am_latitude=34.691694&am_city=%E9%83%91%E5%B7%9E%E5%B8%82&am_loc_time=1497234546228&count=30&min_time=1497234549&screen_width=1080&double_col_mode=0&local_request_tag=1497234618774&iid=11145712454&device_id=36828992557&ac=wifi&channel=wandoujia&aid=7&app_name=joke_essay&version_code=633&version_name=6.3.3&device_platform=android&ssmix=a&device_type=R7c&device_brand=OPPO&os_api=19&os_version=4.4.4&uuid=868239029775439&openudid=ed543142dea45e0e&manifest_version_code=633&resolution=1080*1920&dpi=480&update_version_code=6331";
var url = "http://47.93.192.69:3000/wy?myUrl=" + myUrl;
