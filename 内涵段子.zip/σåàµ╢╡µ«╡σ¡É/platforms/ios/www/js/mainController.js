/**
 * Created by qingyun on 2017/6/12.
 */
angular.module('mainCtrlModule',[])
  .controller('mainCtrl',function ($scope,$http,$sce,$state) {
    // var myUrl = "http://lf.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10953968120&os_version=10.3.2&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=49F24CF2-60CA-480D-9E74-E348052137A1&live_sdk_version=174&vid=0F90E4E0-887F-4D99-946D-0FD18F2F7B88&openudid=5c1db3fba84cbf6570e3d49bda5ff795f79bb3af&device_type=iPhone%206&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=36721904940&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-101&count=30&double_col_mode=0&essence=1&latitude=34.69081309026939&longitude=113.7102160276433&message_cursor=0&min_time=1497254317&mpic=1";
    var url = "http://47.93.192.69:3000/wy?myUrl=" ;
    var interfaces = [{
    title: '推荐',
    url: 'http://iu.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-101&count=30&double_col_mode=0&essence=1&latitude=34.69644924596631&longitude=113.7106233356969&message_cursor=0&min_time=1497226607&mpic=1'
    },{
      title:'视频',
      url:'http://iu.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-104&count=30&double_col_mode=0&essence=1&latitude=34.69296316920222&longitude=113.7117701924462&message_cursor=0&min_time=1497254794&mpic=1'
    },{
      title:'段友秀',
      url:'http://lf.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-301&count=30&double_col_mode=1&essence=1&latitude=34.69644924596631&longitude=113.7106233356969&message_cursor=0&min_time=1497250345&mpic=1'
    },{
      title:'图片',
      url:'http://is.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-103&count=30&double_col_mode=0&essence=1&latitude=34.69644924596631&longitude=113.7106233356969&message_cursor=0&min_time=1497250578&mpic=1',
    },{
      title:'段子',
      url:"http://is.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-102&count=30&double_col_mode=0&essence=1&latitude=34.69644924596631&longitude=113.7106233356969&message_cursor=0&min_time=1497250614&mpic=1",
    },{
      title:'同城',
      url:'http://is.snssdk.com/neihan/stream/mix/v1/?tag=joke&iid=10497168597&os_version=9.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=1E23E230-81B2-4432-97E6-C64820A92191&live_sdk_version=174&vid=B45F8CA5-F433-4154-9FB3-9D90592C98B6&openudid=80623802431fab9942e194ccf1c0a04a0ed7ea15&device_type=iPhone%206S&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=16189168038&aid=7&city=%E6%B2%B3%E5%8D%97%E7%9C%81&content_type=-201&count=30&double_col_mode=0&essence=1&latitude=34.69644924596631&longitude=113.7106233356969&message_cursor=0&min_time=1497250751&mpic=1'
    }]

    $('li').each(function (i,v) {
      $(v).text(interfaces[i].title);
      v.baseUrl = interfaces[i].url;
    })
  var dataxq = '';
   function wlqq(myUrl,callback) {
     $http({
       method: 'GET',
       url: url+myUrl,
     }).then(function success (res) {
       dataxq = res.data.data.data;
       $scope.arr = res.data.data.data;
       console.log($scope.arr);
     }, function error (err) {
       console.log("错误");

     });

     $scope.doRefresh = function() {
       $http.get("http://47.93.192.69:3000/wy?myUrl="+ interfaces[0].url)
         .success(function(res) {
           var datas=res.data.data;
           console.log(res);
           $scope.arr = datas;
         })
         .finally(function() {
           // 停止广播ion-refresher
           $scope.$broadcast('scroll.refreshComplete');
         });
     };

     $scope.jinru = function (index) {



       $state.go('tab.xiangqing',{abc:dataxq[index]})
     }


     $scope.loadMore=function(){
       $http.get("http://47.93.192.69:3000/wy?myUrl="+ interfaces[0].url)
         .success(function(res) {
           for (var i=0;i<res.data.data.length;i++){//newItems.content.length，当前json的数量
             $scope.arr.push(res.data.data[i]);//一个一个取出来，推送到原来的items里
           }
           if (res.data.data.length < 10) {//当json的数量小于10（已经确定了一页为10条数据），说明页面到底了
             $scope.noMorePage=true;//禁止滚动触发时间
           }
           $scope.$broadcast('scroll.infiniteScrollComplete');
         })
     };




   }
//默认页面
    wlqq(interfaces[0].url,function (data) {
      $scope.arr = data;
    })
    //点击切换

    $('ul').on('click','li',function (e) {
      var url = e.target.baseUrl;
      $(e.target).addClass('border').siblings().removeClass('border')
      wlqq(url,function (data) {
        $scope.arr = data;
      })
    })


    $scope.trustSrc = function (url) {
      return  $sce.trustAsResourceUrl(url);
    }


  })
