/**
 * Created by qingyun on 2017/6/12.
 */
angular.module('findCtrlModule',[])
  .controller('findCtrl',function ($scope,$http) {
    var array = [{url: 'http://hotsoon.snssdk.com/hotsoon/banner/?type=recommend&live_sdk_version=174&iid=10931389922&device_id=36707899647&ac=wifi&channel=oppo-cpa&aid=7&app_name=joke_essay&version_code=633&version_name=6.3.3&device_platform=android&ssmix=a&device_type=OPPO+A53&device_brand=OPPO&os_api=22&os_version=5.1.1&uuid=861078033334966&openudid=f93da82e872b5185&manifest_version_code=633&resolution=720*1200&dpi=320&update_version_code=6331'},
      {url:'http://lf.snssdk.com/neihan/category/post_list/?iid=10926236007&os_version=10.3.1&os_api=18&app_name=joke_essay&channel=App%20Store&device_platform=iphone&idfa=8823CD00-B175-4C98-8DC2-F5E3401D0FE9&live_sdk_version=174&vid=8DAF5E0E-E8E8-4E9A-979D-F5DF9B663E90&openudid=2c0216f887499c8f1990470668517a7cf650c5c2&device_type=iPhone%206&version_code=6.3.1&ac=WIFI&screen_width=750&device_id=5828069304&aid=7'}];

    function resData(a,b) {
      $http({
        method:'GET',
        url:'http://47.93.192.69:3000/wy?myUrl='+a,
      }).success(function (data) {
        console.log(data.data);
        $scope.array = data.data;
      }).error(function (a) {
        console.log('请求失败');
      })
    }
    resData(array[1].url);
  })
