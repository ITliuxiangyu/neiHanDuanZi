/**
 * Created by qingyun on 2017/6/12.
 */
angular.module('newsCtrlModule',[])
  .controller('newsCtrl',function ($scope) {

  })
